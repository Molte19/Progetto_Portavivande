﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace Inseriscicomandiveicolo
{
    class metodi
    {
        /*Sets the data rate in bits per second (baud) for serial data transmission.
         * For communicating with the computer, use one of these rates:
         * 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 28800, 38400, 57600, or 115200*/

        //crezione porta seriale con un boun rate fra quelli indicati sopra

      /* public  void trovaleporte() // ho dovuto mettere public in quanto  senza, il form non ha accesso ai metodi 
        {
            string[] ports = SerialPort.GetPortNames();

            Console.WriteLine("The following serial ports were found:");

            // Display each port name to the console.
            foreach (string port in ports)
            {
                switch (port)
                {
                    case port:
                        //portascelta(port);
                        break;
                }

            }

        }*/


       public string invialistacomandi(SerialPort sp, List<string> comandi)
        {
           
            try
            {
                foreach (string comando in comandi)//invio ogni elemento della lista
                    sp.Write(comando);
               return"Invio riuscito";
            }
            catch (Exception e)
            {
                return "Invio non riuscito";
            }

        }
    }
}
