﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;


namespace Inseriscicomandiveicolo
{

   
    public partial class Form1 : Form
    {
        
        List<string> listacomandi = new List<string>();
       
        SerialPort sp = new SerialPort("",1440); // creo l'oggetto porta con nome della porta e il bound rate
        metodi met = new metodi();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void conferma_Click(object sender, EventArgs e)
        {

           
            string ris =  met.invialistacomandi(sp, listacomandi); // metto in una stringa il messaggio di ritorno del metodo invialista comandi (invio riuscito o non riuscito)
            MessageBox.Show(ris, "", MessageBoxButtons.OK);
            listacomandi = new List<string>();
        }

        private void avanti_Click(object sender, EventArgs e)
        {
            listacomandi.Add("avanti");
        }

        private void destra_Click(object sender, EventArgs e)
        {
            listacomandi.Add("destra");
        }

        private void sinistra_Click(object sender, EventArgs e)
        {
            listacomandi.Add("sinistra");
        }

        private void indietro_Click(object sender, EventArgs e)
        {
            listacomandi.Add("indietro");
        }
    }
}
