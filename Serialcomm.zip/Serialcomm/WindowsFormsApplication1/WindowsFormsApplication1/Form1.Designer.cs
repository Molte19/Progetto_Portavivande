﻿namespace Inseriscicomandiveicolo
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.avanti = new System.Windows.Forms.Button();
            this.destra = new System.Windows.Forms.Button();
            this.indietro = new System.Windows.Forms.Button();
            this.sinistra = new System.Windows.Forms.Button();
            this.conferma = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // avanti
            // 
            this.avanti.Location = new System.Drawing.Point(145, 67);
            this.avanti.Name = "avanti";
            this.avanti.Size = new System.Drawing.Size(75, 33);
            this.avanti.TabIndex = 0;
            this.avanti.Text = "Avanti";
            this.avanti.UseVisualStyleBackColor = true;
            this.avanti.Click += new System.EventHandler(this.avanti_Click);
            // 
            // destra
            // 
            this.destra.Location = new System.Drawing.Point(236, 128);
            this.destra.Name = "destra";
            this.destra.Size = new System.Drawing.Size(91, 35);
            this.destra.TabIndex = 1;
            this.destra.Text = "Gira a destra";
            this.destra.UseVisualStyleBackColor = true;
            this.destra.Click += new System.EventHandler(this.destra_Click);
            // 
            // indietro
            // 
            this.indietro.Location = new System.Drawing.Point(145, 195);
            this.indietro.Name = "indietro";
            this.indietro.Size = new System.Drawing.Size(75, 31);
            this.indietro.TabIndex = 2;
            this.indietro.Text = "Indietro";
            this.indietro.UseVisualStyleBackColor = true;
            this.indietro.Click += new System.EventHandler(this.indietro_Click);
            // 
            // sinistra
            // 
            this.sinistra.Location = new System.Drawing.Point(33, 128);
            this.sinistra.Name = "sinistra";
            this.sinistra.Size = new System.Drawing.Size(92, 35);
            this.sinistra.TabIndex = 3;
            this.sinistra.Text = "Gira a sinistra";
            this.sinistra.UseVisualStyleBackColor = true;
            this.sinistra.Click += new System.EventHandler(this.sinistra_Click);
            // 
            // conferma
            // 
            this.conferma.Location = new System.Drawing.Point(277, 214);
            this.conferma.Name = "conferma";
            this.conferma.Size = new System.Drawing.Size(75, 23);
            this.conferma.TabIndex = 4;
            this.conferma.Text = "Conferma";
            this.conferma.UseVisualStyleBackColor = true;
            this.conferma.Click += new System.EventHandler(this.conferma_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 310);
            this.Controls.Add(this.conferma);
            this.Controls.Add(this.sinistra);
            this.Controls.Add(this.indietro);
            this.Controls.Add(this.destra);
            this.Controls.Add(this.avanti);
            this.Name = "Form1";
            this.Text = "Invia comandi";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button avanti;
        private System.Windows.Forms.Button destra;
        private System.Windows.Forms.Button indietro;
        private System.Windows.Forms.Button sinistra;
        private System.Windows.Forms.Button conferma;

    }
}

