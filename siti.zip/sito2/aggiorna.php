


<html>
<head>

<title>Welcome <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link rel="stylesheet" href="stile.css" type="text/css" />
</head>
<body>


<form>
<?php
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
</form>

<form>
<input type="button" value="Indietro" onClick="javascript:history.back()" name="button">
</form>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
					
$sql = "UPDATE magazzino 
SET quantita = quantita + '{$_POST['quant']}'
WHERE nome = '{$_POST['nomee']}'";

?>

</body>
</html>