


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link rel="stylesheet" href="stile.css" type="text/css" />
</head>
<body>


<form>

<?php

foreach($rows as $row)
{

echo "<table><td>".$row['nome']."  ".$row['quantita']."</td></table> &nbsp";


}

?>

</form>



<form>
<input type="button" value="Indietro" onClick="javascript:history.back()" name="button">
</form>
</body>
</html>
<?php //con msqli
$mysqli = new mysqli("localhost", "root", "", "dbtest");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$query = "SELECT * FROM magazzino WHERE 1 ";
$result = $mysqli->query($query);

while($row = $result->fetch_array())
{
$rows[] = $row;
}



/* free result set */
$result->close();

/* close connection */
$mysqli->close();
?>