
<?php //con msqli
$mysqli = new mysqli("localhost", "root", "", "dbtest");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$query = "SELECT * FROM ordini WHERE 1 ";
$result = $mysqli->query($query);

while($row = $result->fetch_array())
{
$rows[] = $row;
}



/* free result set */
$result->close();

/* close connection */
$mysqli->close();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link rel="stylesheet" href="stile.css" type="text/css" />
</head>
<body>


<form>

<?php

foreach($rows as $row)
{

echo "<BR><tr><td><h2> NOME: ".$row['nome']."</h2> <BR>  <h2>STANZA: ".$row['stanza']."</h2> <BR>";

                    if($row['coca']>0)
					{
					echo "</h2> <BR> <h2> COCA: ".$row['coca']."</h2> <BR>  &nbsp";

					}
					
					if($row['fanta']>0)
					{
					echo "</h2> <BR> <h2> FANTA: ".$row['fanta']."</h2> <BR>  &nbsp";

					}
					
					if($row['sprite']>0)
					{
					echo "</h2> <BR> <h2> SPRITE: ".$row['sprite']."</h2> <BR>  &nbsp";
					}
					
						if($row['birra']>0)
					{
					echo "</h2> <BR> <h2> SPRITE: ".$row['birra']."</h2> <BR>  &nbsp";
					}
					
						if($row['becks']>0)
					{
					echo "</h2> <BR> <h2> BECKS: ".$row['becks']."</h2> <BR>  &nbsp";
					}
					
						if($row['guinnes']>0)
					{
					echo "</h2> <BR> <h2> GUINNES: ".$row['guinnes']."</h2> <BR>  &nbsp";
					}
}

?>

</form>



<form>
<input type="button" value="Indietro" onClick="javascript:history.back()" name="button">
</form>
</body>
</html>