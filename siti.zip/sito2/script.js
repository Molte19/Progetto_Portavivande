
function checkLogin() {

	var errorSentinel=true;//variabile sentinella.
	
	var usn = document.getElementById("username").value;
	var psw = document.getElementById("password").value;
	
	if(usn==""){
	document.getElementById("usn").style.color="red";
	errorSentinel=false;
	}

	
	if(psw==""){
	document.getElementById("psw").style.color="red";
	errorSentinel=false;
	}
	else
	document.getElementById("psw").style.color="black";

	return errorSentinel;
	
}

 function logout(){
       session_destroy();  // Like `PHP` I want destroy Session in `javascript`
      }

function showSignup(){
	document.getElementById("regDiv").style.display = 'block';

}





function checkSignup(){

	var errorSentinel=true;//variabile sentinella.
	
	var nome = document.getElementById("nome").value;
	var usn = document.getElementById("usernameReg").value;
	var psw1 = document.getElementById("passwordReg1").value;
	var psw2 = document.getElementById("passwordReg2").value;
	
	if(nome==""){
	document.getElementById("nm").style.color="red";
	errorSentinel=false;
	}
	else
	document.getElementById("nm").style.color="black";
	
	if(usn==""){
	document.getElementById("usnReg").style.color="red";
	errorSentinel=false;
	}
	
	if(psw1==""){
	document.getElementById("pswReg1").style.color="red";
	errorSentinel=false;
	}
	
	if(psw2==""){
	document.getElementById("pswReg2").style.color="red";
	errorSentinel=false;
	}
	else
	document.getElementById("pswReg2").style.color="black";
	
	return errorSentinel;
}