<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>



<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.4.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/loopedslider.js" type="text/javascript" charset="utf-8"></script>

</head>
<body>

          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['username']; ?></a></li>
            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
   
   
   
 
   
   <div id="topbanner">

<h1 id="sitename">
Robot portavivande
<span>Cibo e Bevande senza fare sforzi!!</span>
</h1>
</div>
<div id="wrap">
<div id="header">
<div id="slider">	
	<div class="container">
		<ul class="slides">
			<li><div class="thumbholder"><img src="images/slide1.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
            <p>ordina quello che preferisci </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide2.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
          <p>ordina quello che preferisci </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide1.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
          <p>ordina quello che preferisci  </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide2.jpg" width="625" height="254" alt="First Image" /></div>
            <div class="txtholder">
            <h2>BENVENUTO</h2>
            <p>ordina quello che preferisci  </p></div></li>
			
		</ul>
	</div>
	<ul class="pagination">
		<li><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li><a href="#">4</a></li>
	</ul>	
</div>
</div>
<div id="menu">
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="home2.php">Colazione </a></li>
<li><a href="home3.php" >Pranzo</a></li>
<li><a href="home4.php">Cena</a></li>
<li  class="active" ><a>Carrello</a></li>
<li><a href="home6.php">Contattaci</a></li>


</ul>
</div>
<div id="submenu">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">novita</a></li>


</ul>
</div>
<div id="content">
<div id="maincontent">

    CARELLO: 

      <?php //con msqli
if(isset($_POST['btn-ordina']))
{
	
	
	
	
$mysqli = new mysqli("localhost", "root", "", "dbtest");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
$user=$_SESSION['userSession'];
$query = "SELECT * FROM carrello WHERE id= '$user'";
$result = $mysqli->query($query);

while($row = $result->fetch_array())
{
$rows[] = $row;
}

foreach($rows as $row)
{
echo "<BR><tr><td><h2> NOME: ".$row['nome']."</h2> <BR>  <h2>STANZA: ".$row['stanza']."</h2> <BR>";

                    if($row['coca']>0)
					{
					echo "</h2> <BR> <h2> COCA: ".$row['coca']."</h2> <BR>  &nbsp";

					}
					
					if($row['fanta']>0)
					{
					echo "</h2> <BR> <h2> FANTA: ".$row['fanta']."</h2> <BR>  &nbsp";

					}
					
					if($row['sprite']>0)
					{
					echo "</h2> <BR> <h2> SPRITE: ".$row['sprite']."</h2> <BR>  &nbsp";
					}
					
						if($row['birra']>0)
					{
					echo "</h2> <BR> <h2> SPRITE: ".$row['birra']."</h2> <BR>  &nbsp";
					}
					
						if($row['becks']>0)
					{
					echo "</h2> <BR> <h2> BECKS: ".$row['becks']."</h2> <BR>  &nbsp";
					}
					
						if($row['guinnes']>0)
					{
					echo "</h2> <BR> <h2> GUINNES: ".$row['guinnes']."</h2> <BR>  &nbsp";
					}
					
						if($row['bounty']>0)
					{
					echo "</h2> <BR> <h2> BOUNTY: ".$row['bounty']."</h2> <BR>  &nbsp";
					}
					
						if($row['duplo']>0)
					{
					echo "</h2> <BR> <h2> DUPLO: ".$row['duplo']."</h2> <BR>  &nbsp";
					}
					
						if($row['kinderbueno']>0)
					{
					echo "</h2> <BR> <h2> KINDER: ".$row['kinderbueno']."</h2> <BR>  &nbsp";
					}
					
						if($row['lion']>0)
					{
					echo "</h2> <BR> <h2> LION: ".$row['lion']."</h2> <BR>  &nbsp";
					}
					
						if($row['snikers']>0)
					{
					echo "</h2> <BR> <h2> SNIKERS: ".$row['snikers']."</h2> <BR>  &nbsp";
					}
					
						if($row['tronky']>0)
					{
					echo "</h2> <BR> <h2> TRONKY: ".$row['tronky']."</h2> <BR>  &nbsp";
					}
					
					if($row['primo']>0)
					{
					echo "</h2> <BR> <h2> TAGLIATELLE: ".$row['primo']."</h2> <BR>  &nbsp";
					}
					
					if($row['primo2']>0)
					{
					echo "</h2> <BR> <h2> RAVIOLI: ".$row['primo2']."</h2> <BR>  &nbsp";
					}
					
					if($row['primo3']>0)
					{
					echo "</h2> <BR> <h2> ORECCHIETTE: ".$row['primo3']."</h2> <BR>  &nbsp";
					}
					
					if($row['secondo']>0)
					{
					echo "</h2> <BR> <h2> POLLO: ".$row['secondo']."</h2> <BR>  &nbsp";
					}
					
					if($row['secondo2']>0)
					{
					echo "</h2> <BR> <h2> CARNE: ".$row['secondo2']."</h2> <BR>  &nbsp";
					}
					
					if($row['secondo3']>0)
					{
					echo "</h2> <BR> <h2> ARROSTO: ".$row['secondo3']."</h2> <BR>  &nbsp";
					}




}

/* free result set */
$result->close();

/* close connection */
$mysqli->close();
}
?>
			


			<br>
			<br>
			<br>
	
	<form id="" align="center"  method="post" action="ordini.php">

   <button  id="agg" type="submit" class="btn btn-default" name="btn-ordina">
      <span  class="glyphicon glyphicon-log-in"></span> &nbsp; conferma ordine
   </button> 

   
   </form>



</div>
<div id="sidebar1">
<h2 class="subhead">Categorie</h2>
<ul class="menu">
<li><a href="cibo.php">cibo</a></li>
<li><a href="prova.php">bevande</a></li>
<li><a href="primi.php">primi</a></li>
<li><a href="secondi.php">secondi</a></li>




</ul>
</div>
<div class="clear"></div>
</div>
<div id="footer">
&copy; RobotPortavivande | all Rights Reserved
<span class="credit"><a href="http://www.cssheaven.org">cell:031456543</a> via isonzo 4 Milano</span>

</div>
</div>
<script type="text/javascript" charset="utf-8">
	$(function(){
		$('#slider').loopedSlider({
			autoStart: 2500,
			restart: 5000
		});
		
	});
</script>





	 
	 
	  
	  
	  
	  

<div class="container" style="margin-top:150px;text-align:center;font-family:Verdana, Geneva, sans-serif;font-size:35px;">
 
   
</div>

</body>
</html>

