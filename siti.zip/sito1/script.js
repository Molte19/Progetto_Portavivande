var v = [];
var i = -1;
//var j = -1;
var xm=0;
var xr = 0;
var xw = 0;
var xc = 0;
var xp = 0;
var xs = 0;
function bevanda(nome) {
    i++;
    //j++;
     xm = 0;
     xr = 0;
     xw = 0;
     xc = 0;
     xp = 0;
     xs = 0;
    var objris = document.getElementById("risultato");
    objris.innerText = " ";
    if(nome=="coca")
        v[i] = "coca";
    else if (nome == "fanta")
        v[i] = "fanta";
    else if (nome == "acqua")
        v[i] = "acqua";
    for (var j = 0; j < v.length; j++) {
         if (v[j] == "coca") {
            xm++;
          //  vet(xm, j);
        }
        else if (v[j] == "fanta") {
            xw++;
           // vet(xw, j);
        }
        else if (v[j] == "acqua") {
            xc++;
           // vet(xc, j);
        }
      
    }
    // }*/
    vet(xm, xw, xr, xs, xc, xp);
}

function vet(x,j,e,s,a,f)
{
    var objris = document.getElementById("risultato");
    if(xm>0)
        objris.innerText += "\n" + " " + x + "coca ";
    if(xw>0)
        objris.innerText += "\n" + " " + j + "fanta";
    
    if(xc>0)
        objris.innerText += "\n" + " " + a + "acqua";
   
}

function invia()
{

}