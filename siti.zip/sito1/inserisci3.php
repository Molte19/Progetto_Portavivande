<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link rel="stylesheet" href="style.css" type="text/css" />


</head>
<body>

<form>
<input id="agg" align="center" type="button" value="ok" onClick="javascript:history.back()" name="button">
</form>
</body>
</html>
<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}


$query = $MySQLi_CON->query("SELECT * FROM users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>

<?php

if(isset($_POST['btn-inserisci']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
		$user=$_SESSION['userSession'];
		
		$sql="SELECT id FROM carrello WHERE id='$user'";
		
			if($sql=$user){
				
$sql = "UPDATE carrello
SET coca = coca + '{$_POST['coca']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 



$sql = "UPDATE carrello
SET fanta = fanta + '{$_POST['fanta']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 


$sql = "UPDATE carrello
SET sprite = sprite + '{$_POST['sprite']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET birra = birra + '{$_POST['birra']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET becks = becks + '{$_POST['becks']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET bounty = bounty + '{$_POST['bounty']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET duplo = duplo + '{$_POST['duplo']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET kinderbueno = kinderbueno + '{$_POST['kinderbueno']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET lion = lion + '{$_POST['lion']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET snikers = snikers + '{$_POST['snikers']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET tronky = tronky + '{$_POST['tronky']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET guinnes = guinnes + '{$_POST['guinnes']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET primo = primo + '{$_POST['primo']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET primo2 = primo2 + '{$_POST['primo2']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET primo3 = primo3 + '{$_POST['primo3']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET secondo = secondo + '{$_POST['secondo']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET secondo2 = secondo2 + '{$_POST['secondo2']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 

$sql = "UPDATE carrello
SET secondo3 = secondo3 + '{$_POST['secondo3']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo " ";
} 


$conn->close();


				
			            }
						
						
if($sql!=$user)
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO carrello (id,nome,stanza,coca,fanta,sprite,birra,becks,guinnes,bounty,duplo,kinderbueno,lion,snikers,tronky,primo,primo2,primo3,secondo,secondo2,secondo3)
VALUES ('$user','{$_POST['nome']}', '{$_POST['stanza']}','0','0','0','0','0','0','0','0','0','0','0','0','{$_POST['primo']}','{$_POST['primo2']}','{$_POST['primo3']}','0','0','0') ";

if ($conn->query($sql) === TRUE) {
    echo " ";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
					
}

}


?>