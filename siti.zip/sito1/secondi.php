<?php
$mysqli = new mysqli("localhost", "root", "", "dbtest");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$query = "SELECT * FROM magazzino WHERE nome='secondo' " ;
$result = $mysqli->query($query);

while($row = $result->fetch_array())
{
$rows[] = $row;
}

foreach($rows as $row)
{
}

$query2 = "SELECT * FROM magazzino WHERE nome='secondo2' " ;
$result2 = $mysqli->query($query2);

while($row2 = $result2->fetch_array())
{
$rows2[] = $row2;
}

foreach($rows2 as $row2)
{
}


$query3 = "SELECT * FROM magazzino WHERE nome='secondo3' " ;
$result = $mysqli->query($query3);

while($row3 = $result->fetch_array())
{
$rows3[] = $row3;
}

foreach($rows3 as $row3)
{
}


/* free result set */
$result->close();

/* close connection */
$mysqli->close();
?>


<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}

$query = $MySQLi_CON->query("SELECT * FROM users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 



   <link href="style.css" rel="stylesheet" type="text/css" />
    <meta charset="UTF-8">
    <meta name="description" content="bevanda">
    <script type="text/javascript" src="script.js"></script>
	
	
	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.4.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/loopedslider.js" type="text/javascript" charset="utf-8"></script>

</head>
<body>

          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['username']; ?></a></li>
            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
          </ul>
   
   
   
 
   
<div id="topbanner">

<h1 id="sitename">
Robot portavivande
<span>Cibo e Bevande senza fare sforzi!!</span>
</h1>
</div>
<div id="wrap">
<div id="header">
<div id="slider">	
	<div class="container">
		<ul class="slides">
			<li><div class="thumbholder"><img src="images/slide1.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
            <p>ordina quello che preferisci </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide2.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
          <p>ordina quello che preferisci </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide1.jpg" width="625" height="254" alt="First Image" /></div><div class="txtholder">
            <h2>BENVENUTO</h2>
          <p>ordina quello che preferisci  </p></div></li>
            
            <li><div class="thumbholder"><img src="images/slide2.jpg" width="625" height="254" alt="First Image" /></div>
            <div class="txtholder">
            <h2>BENVENUTO</h2>
            <p>ordina quello che preferisci  </p></div></li>
			
		</ul>
	</div>
	<ul class="pagination">
		<li><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li><a href="#">4</a></li>
	</ul>	
</div>
</div>
<div id="menu">
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="home2.php">Colazione </a></li>
<li><a href="home3.php">Pranzo</a></li>
<li  class="active"><a >Cena</a></li>
<li><a href="home5.php">Carrello</a></li>
<li><a href="home6.php">Contattaci</a></li>


</ul>
</div>
<div id="submenu">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">novita</a></li>


</ul>
</div>
<div id="content">
<div id="maincontent">






<!--qui parte dentro   --------------------------------------------------------------------------------------- -->
   


    
        <form id="" align="center" method="post" action="inserisci4.php">
<h2> Scelta secondo: </h2> </br>
       
	   
	   
               <tr align="center" >
                   <td  width="50%">
				   
				<h2 align="center" > <b> BENVENUTO </b> </h2> <br>
				<h2 align="center" >Stanza
				<input type="text" name="stanza" /></h2><br>
				
				   
				   
				   

				   <h2 align="center" >nome
					 <input   type="text" name="nome"  /></h2><br>
					 
					<?php if($row['quantita']>0)
					{
					//echo $row['nome']."</td></tr> &nbsp";
					}
					else
					{
						
						echo "non disp->" ;
						
					}
					?>
					 <img src="immagini/secondo.png" alt="breve descrizione dell'immagine">
					 <label align="center" name="coc" >quantita</label>&nbsp;&nbsp;
					 <input  type="text" value="0" title="0"
   onfocus = "if (this.value == this.title) this.value = '';" 
   onblur = "if (this.value == '') this.value = this.title" name="secondo" />
   <br>
   
					 
					 
					  <?php if($row2['quantita']>0)
					{
					//echo $row['nome']."</td></tr> &nbsp";
					}
					else
					{
						echo "non disp->" ;
					}
					?>
					 <img src="immagini/secondo2.png" alt="breve descrizione dell'immagine">
                     <label align="center">quantita</label>
					 <input  type="text" value="0" title="0"
   onfocus = "if (this.value == this.title) this.value = '';" 
   onblur = "if (this.value == '') this.value = this.title" name="secondo2"  /><br>
					  <br>
					 
					  <?php if($row3['quantita']>0)
					{
					//echo $row['nome']."</td></tr> &nbsp";
					}
					else
					{
						echo "non disp->" ;
					}
					?>
					 <img src="immagini/secondo3.png" alt="breve descrizione dell'immagine">
					  <label align="center" >quantita</label>
					 <input  type="text"  value="0" title="0"
   onfocus = "if (this.value == this.title) this.value = '';" 
   onblur = "if (this.value == '') this.value = this.title" name="secondo3"  />
					 
					 <br>
   <button  id="agg" type="submit" class="btn btn-default" name="btn-inserisci">
      <span  class="glyphicon glyphicon-log-in"></span> &nbsp; aggiungi al carrello
   </button> 
   
   
   
   </form>
					
					
					
</td>
                   <td  width="50%">
                       <div id="div1" align="center"> <p id="risultato"></p> </div>
                   </td>
               </tr>
           
         </center>
        </form>
	

	
<form align="center">
<input id="indietro" type="button" value="Indietro" onClick="javascript:history.back()" name="button">
</form>


		

<!--fine parte dentro   --------------------------------------------------------------------------------------- -->











</div>
<div id="sidebar1">
<h2 class="subhead">Categorie</h2>
<ul class="menu">
<li><a href="cibo.php">cibo</a></li>
<li><a href="prova.php">bevande</a></li>
<li><a href="primi.php">primi</a></li>
<li><a href="#">secondi</a></li>




</ul>
</div>
<div class="clear"></div>
</div>
<div id="footer">
&copy; RobotPortavivande | all Rights Reserved
<span class="credit"><a href="http://www.cssheaven.org">cell:031456543</a> via isonzo 4 Milano</span>

</div>
</div>
<script type="text/javascript" charset="utf-8">
	$(function(){
		$('#slider').loopedSlider({
			autoStart: 2500,
			restart: 5000
		});
		
	});
</script>





	 
	 
	  
	  
	  
	  

<div class="container" style="margin-top:150px;text-align:center;font-family:Verdana, Geneva, sans-serif;font-size:35px;">
 
   
</div>

</body>
</html>