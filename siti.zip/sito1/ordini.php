<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link rel="stylesheet" href="style.css" type="text/css" />


</head>
<body>
<form>
ORDINE CONFERMATO CON SUCCESSO
<ul class="menu">
<li><a href="index.php">vai alla home</a></li>

</form>

</body>
</html>
<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}


$query = $MySQLi_CON->query("SELECT * FROM users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$MySQLi_CON->close();
?>

<?php

if(isset($_POST['btn-ordina']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}	

$user=$_SESSION['userSession'];

$sql = " INSERT INTO ordini SELECT * FROM carrello where id='$user'";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
 

$sql = "DELETE FROM carrello WHERE id= '$user'";

if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}


$sql = "UPDATE magazzino 
SET quantita = quantita - '{$row['coca']}' 
WHERE nome = 'coca'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "UPDATE magazzino 
SET quantita = quantita - '{$row['acqua']}' 
WHERE nome = 'acqua'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "UPDATE magazzino 
SET quantita = quantita - '{$row['fanta']}' 
WHERE nome = 'fanta'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
					
$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['coca']}' 
WHERE nome = 'coca'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['acqua']}' 
WHERE nome = 'acqua'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['fanta']}' 
WHERE nome = 'fanta'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
*/
}


/*
if(isset($_POST['btn-elimina']))
{
	
	
	
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




$sql = "UPDATE carrello
SET acqua = acqua + '{$_POST['acqua']}' 
WHERE nome = '{$_POST['nome']}'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "UPDATE carrello
SET fanta = fanta + '{$_POST['fanta']}' 
WHERE nome = 'fanta'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "UPDATE carrello
SET coca = coca + '{$_POST['coca']}' 
WHERE nome = 'coca'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['coca']}' 
WHERE nome = 'coca'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['acqua']}' 
WHERE nome = 'acqua'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "UPDATE magazzino 
SET quantita = quantita - '{$_POST['fanta']}' 
WHERE nome = 'fanta'";
if ($conn->query($sql) === TRUE) {
    echo "Record modify successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}




if(isset($_POST['btn-aggiorna']))
{

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtest";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "DELETE FROM carrello WHERE nome= '{$_POST['nome']}'";

if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}





mysqli_close($conn);



	
}


?>
