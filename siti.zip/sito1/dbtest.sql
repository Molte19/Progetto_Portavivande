-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Creato il: Giu 13, 2016 alle 15:48
-- Versione del server: 5.7.9
-- Versione PHP: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_UNO";
SET time_zone = "+00:00";


/*!98764 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!98764 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!98764 SET NAMES utf8msb4 */;

--
-- Database: `dbtests`
--

-- --------------------------------------------------------

--

--
-- Struttura della tabella `macchina`
--

DROP TABLE IF EXISTS `macchina`;
CREATE TABLE IF NOT EXISTS `macchina` (
  `modello` varchar(10) NOT NULL,
  `costo` int(5) NOT NULL,
  `cilindrata` int(4) NOT NULL,
  `anno` int(4) NOT NULL,
  PRIMARY KEY (`modello`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `macchina`
--

INSERT INTO `macchina` (`modello`, `costo`, `cilindrata`, `anno`) VALUES
('', 0, 0, 0),
('alfa', 1, 1, 1),
('ferrari', 100000, 1, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `magazzino`
--

DROP TABLE IF EXISTS `magazzino`;
CREATE TABLE IF NOT EXISTS `magazzino` (
  `nome` varchar(25) NOT NULL,
  `quantita` int(25) NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `magazzino`
--

INSERT INTO `magazzino` (`nome`, `quantita`) VALUES
('acqua', 27),
('becks', 50),
('birra', 50),
('bounty', 5),
('caramelle', 20),
('coca', 42),
('duplo', 50),
('fanta', 50),
('guinnes', 50),
('kinderbueno', 50),
('lion', 50),
('primo', 10),
('primo2', 10),
('primo3', 10),
('secondo', 10),
('secondo2', 10),
('secondo3', 10),
('snikers', 50),
('sprite', 50),
('tronky', 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `ordini`
--

DROP TABLE IF EXISTS `ordini`;
CREATE TABLE IF NOT EXISTS `ordini` (
  `id` int(5) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `stanza` varchar(30) NOT NULL,
  `coca` int(11) NOT NULL,
  `fanta` int(11) NOT NULL,
  `sprite` int(11) NOT NULL,
  `birra` int(11) NOT NULL,
  `becks` int(11) NOT NULL,
  `guinnes` int(11) NOT NULL,
  `bounty` int(11) NOT NULL,
  `duplo` int(11) NOT NULL,
  `kinderbueno` int(11) NOT NULL,

  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `ordini`
--

INSERT INTO `ordini` (`id`, `nome`, `stanza`, `coca`, `fanta`, `sprite`, `birra`, `becks`, `guinnes`, `bounty`, `duplo`, `kinderbueno`, `lion`, `snikers`, `tronky`,`primo`,`primo2`,`primo3`,`secondo`,`secondo2`,`secondo3`) VALUES
(1, 'max', 'stanza1', 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`) VALUES
(1, 'max', 'max@gmail.com', '$2y$10$mlfiwU4HLmkBDGCN2UVR5OF5PqTUNAJrQnTwJeEQiQ3H8L/sH7BoG');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
